To run the game assign execution permission to: run.sh

Command:
chmod +x run.sh
