chmod +x game5
LD_LIBRARY_PATH=. ./game5